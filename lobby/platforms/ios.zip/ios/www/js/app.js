
angular.module('lobby', ['ionic', 'lobby.controllers', 'lobby.services'])

.factory('$localstorage', ['$window', function($window) {
  return {
    set: function(key, value) {
      $window.localStorage[key] = value;
    },
    get: function(key, defaultValue) {
      return $window.localStorage[key] || defaultValue;
    },
    setObject: function(key, value) {
      $window.localStorage[key] = JSON.stringify(value);
    },
    getObject: function(key) {
      return JSON.parse($window.localStorage[key] || '{}');
    }
  }
}])

.run(function($ionicPlatform, $http, $localstorage, $state) {


  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if(window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }
    if(window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
})

.config(function($stateProvider,$urlRouterProvider) {
  $stateProvider.state('app', {
    abstract: true,
    templateUrl: 'index.html',
    controller: 'AppCtrl'
  })

  $stateProvider.state('app.slide', {
    url: '/slide',
    templateUrl: 'View/slide.html',
    controller: 'SlideCtrl'
  });

  $stateProvider.state('app.signup', {
    url: '/signup',
    templateUrl: 'View/join.html',
    controller: 'SignupCtrl'
  });

  $stateProvider.state('app.login', {
    url: '/login',
    templateUrl: 'View/login.html',
    controller: 'LoginCtrl'
  });

  $urlRouterProvider.otherwise("/slide");
})