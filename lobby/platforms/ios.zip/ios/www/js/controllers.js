angular.module('lobby.controllers', [])
//------------------------------------------------------
//----- sign in
//------------------------------------------------------
.controller('AppCtrl', function($scope, $http, $state, $window, $ionicPopup, $ionicLoading, UrlManager) {
  $scope.parentobj = {};
  $scope.parentobj.backType = 'Signup';
})
.controller('SlideCtrl', function($scope, $http, $state, $window, $ionicPopup, $ionicLoading, UrlManager) {

    $scope.he = $window.innerHeight;
    angular.element($window).bind('resize', function() {
      $scope.he = $window.innerHeight;
    });

    

    document.body.style.backgroundImage = "url('images/welcome_screen_background_one.png')";
    $scope.slideHasChanged = function($index){
      //alert($index);
      switch ($index){
        case 0:
          document.getElementById("slide").style.backgroundImage = "url('images/welcome_screen_background_one.png')";
          break;
        case 1:
          document.getElementById("slide").style.backgroundImage = "url('images/welcome_screen_background_two.png')";
          break;
        case 2:
          document.getElementById("slide").style.backgroundImage = "url('images/welcome_screen_background_three.png')";
          break;
        case 3:
          document.getElementById("slide").style.backgroundImage = "url('images/welcome_screen_background_four.png')";
          break;
      }
      
    }

    $scope.signup = function(){
      $state.go("app.signup");
      $scope.parentobj.backType = 'Signup';
    }
    $scope.login = function(){
      $state.go("app.login");
      $scope.parentobj.backType = 'Login';
    }
})

.controller('SignupCtrl', function($scope, $http, $state, $window, $ionicPopup, $ionicLoading, UrlManager) {
    $scope.selected = -1;
    $scope.visiblestate = "HIDE";

    

    $scope.isSelected = function(type) {
        if(type == $scope.selected) {
            return "selected";
        } else {
            return "";
        }
    }

    $scope.selectItem = function(type) {
        $scope.selected = type;
    }

    $scope.visible1 = function(){
        if($scope.visiblestate == "HIDE"){
            $scope.visiblestate = "SHOW";
        }else if($scope.visiblestate == "SHOW"){
            $scope.visiblestate = "HIDE";
        }
    }
})

.controller('LoginCtrl', function($scope, $http, $state, $window, $ionicPopup, $ionicLoading, UrlManager) {
  $scope.selected = -1;
    $scope.visiblestate = "HIDE";
    

    $scope.isSelected = function(type) {
        if(type == $scope.selected) {
            return "selected";
        } else {
            return "";
        }
    }

    $scope.selectItem = function(type) {
        $scope.selected = type;
    }

    $scope.visible1 = function(){
        if($scope.visiblestate == "HIDE"){
            $scope.visiblestate = "SHOW";
        }else if($scope.visiblestate == "SHOW"){
            $scope.visiblestate = "HIDE";
        }
    }
})



